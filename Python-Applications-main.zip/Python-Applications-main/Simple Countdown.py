x = True
y = 99999
while x == True:
    print("Countdown >>> " + str(y))
    y -= 1
    
